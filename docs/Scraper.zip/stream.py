from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import json

# THESE ARE MINE
consumer_key = '3oROKU5NGQyRYGD4Xt0hQg'
consumer_secret = 'yL9L1NCl3eul3DHT7Wqip1XWzcInaN2oBn7O3w2gU'

# DON'T COPY PUBLICALLY!
access_token = '807061093-r8ao4gr7ka9uttGTqM56GaYkgs4T7cvWHV6eDFL5'
access_token_secret = 'XQnGVhAFgMRqGkoOrFxS3vYH5SttTBhvUI2VynxWFs'


class StdOutListener(StreamListener):
    """ A listener handles tweets are the received from the stream.
    This is a basic listener that just dumps to a file.

    """
    def __init__(self, filename):
        self.myfile = open(filename, "a")

    def on_data(self, data):
        self.myfile.write(data)
        return True

    def on_error(self, status):
        print status


if __name__ == '__main__':
    l = StdOutListener("bda.dump")
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)

    stream = Stream(auth, l)

    # If we wish to filter on a particular topic...
    # stream.filter(track=['#marchmadness', 'march madness'])
    try:
        stream.sample()
    except Exception:
        print "Done scraping, cleaning..."
        l.myfile.close()

    f = open("bda.dump")
    content = f.read()
    f.close()

    # API dumps with \r\n returns between each
    raw_tweets = content.split("\r\n")

    # divvy up the tweets to unique files for indexing with solr (lucene)
    for tweet in raw_tweets:
        j = json.loads(tweet.strip())
        f = open('./dumps/' + j['id_str'] + '.txt', 'w')
        f.write(json.dumps(j))
        f.close()
